package modelo.ideia;

public class IdeaAdapter  {
}
